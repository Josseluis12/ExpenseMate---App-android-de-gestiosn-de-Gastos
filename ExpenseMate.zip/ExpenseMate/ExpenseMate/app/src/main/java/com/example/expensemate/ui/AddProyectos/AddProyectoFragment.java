package com.example.expensemate.ui.AddProyectos;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.databinding.FragmentAddProyectoBinding;
import com.example.expensemate.ui.api.ApiClient;
import com.example.expensemate.ui.api.ApiService;
import com.example.expensemate.ui.api.User;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddProyectoFragment extends Fragment {

    private FragmentAddProyectoBinding binding;
    private List<User> usuariosSeleccionados = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAddProyectoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Inicializar vistas
        Button buttonAgregarProyecto = root.findViewById(R.id.button_agregar_proyecto);
        buttonAgregarProyecto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarProyecto();
            }
        });

        obtenerListaUsuarios();

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void obtenerListaUsuarios() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<User>> call = apiService.getUsers();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful()) {
                    List<User> usuarios = response.body();
                    if (usuarios != null) {
                        mostrarUsuarios(usuarios);
                    } else {
                        Toast.makeText(getContext(), "No se encontraron usuarios", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Error al obtener la lista de usuarios", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Toast.makeText(getContext(), "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarUsuarios(List<User> usuarios) {
        UserAdapter userAdapter = new UserAdapter(usuarios, new UserAdapter.OnUserClickListener() {
            @Override
            public void onUserClick(User user, boolean isSelected) {
                if (isSelected) {
                    usuariosSeleccionados.add(user);
                } else {
                    usuariosSeleccionados.remove(user);
                }
            }
        });
        RecyclerView recyclerView = binding.recyclerViewUsers;
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(userAdapter);
    }

    private void agregarProyecto() {
        String nombreProyecto = binding.editTextNombreProyecto.getText().toString();
        // Suponiendo que idAdmin es un String, puedes obtenerlo de algún lugar o pasarlo directamente aquí
        int idAdmin = 12345; // Reemplaza esto con el valor correspondiente

        if (usuariosSeleccionados.isEmpty()) {
            Toast.makeText(getContext(), "Seleccione al menos un usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear una instancia de AddProyectoTask y ejecutarla
        AddProyectoTask addProyectoTask = new AddProyectoTask(nombreProyecto, idAdmin, new AddProyectoTask.AddProyectoListener() {
            @Override
            public void onProyectoAdded() {
                Toast.makeText(getContext(), "Proyecto agregado correctamente", Toast.LENGTH_SHORT).show();
                limpiarCampos();
            }

            @Override
            public void onProyectoAddFailed() {
                Toast.makeText(getContext(), "Error al agregar el proyecto", Toast.LENGTH_SHORT).show();
            }
        });
        addProyectoTask.execute();
    }

    // Método para limpiar los campos después de agregar un proyecto
    private void limpiarCampos() {
        binding.editTextNombreProyecto.setText("");
        binding.editTextDescripcion.setText("");
        usuariosSeleccionados.clear(); // Limpiar la lista de usuarios seleccionados
    }

    private static class AddProyectoTask extends AsyncTask<Void, Void, Boolean> {

        private String nombreProyecto;
        private int idAdmin;
        private AddProyectoListener listener;

        public AddProyectoTask(String nombreProyecto, int idAdmin, AddProyectoListener listener) {
            this.nombreProyecto = nombreProyecto;
            this.idAdmin = idAdmin;
            this.listener = listener;
        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                // Construir la URL
                URL url = new URL("https://josseluis12.eu.pythonanywhere.com/proyectos");

                // Establecer la conexión HTTP
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setDoOutput(true);

                // Construir el cuerpo de la solicitud
                Map<String, Object> requestBody = new HashMap<>();
                requestBody.put("nombre", nombreProyecto);
                requestBody.put("id_admin", idAdmin);

                // Escribir el cuerpo de la solicitud en la conexión
                OutputStream outputStream = connection.getOutputStream();
                OutputStreamWriter writer = new OutputStreamWriter(outputStream);
                writer.write(requestBody.toString());
                writer.flush();
                writer.close();
                outputStream.close();

                // Leer la respuesta del servidor
                int responseCode = connection.getResponseCode();
                Log.d("AddProyectoTask", "Response code: " + responseCode);

                // Comprobar si la solicitud fue exitosa
                return responseCode == HttpURLConnection.HTTP_CREATED;
            } catch (Exception e) {
                Log.e("AddProyectoTask", "Error al agregar el proyecto", e);
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean success) {
            if (success) {
                listener.onProyectoAdded();
            } else {
                listener.onProyectoAddFailed();
            }
        }

        public interface AddProyectoListener {
            void onProyectoAdded();
            void onProyectoAddFailed();
        }
    }
}
