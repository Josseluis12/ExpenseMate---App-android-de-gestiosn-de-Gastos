package com.example.expensemate.ui.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.expensemate.MainActivity;
import com.example.expensemate.R;
import com.example.expensemate.ui.baseD.Usuario;
import com.example.expensemate.ui.baseD.database.AppDatabase;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameLoginEditText;
    private EditText passwordLoginEditText;

    private Button loginButton;
    private Button registerButton;

    private AppDatabase appDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializar la base de datos
        appDatabase = AppDatabase.getDatabase(getApplicationContext());

        // Inicializar vistas
        usernameLoginEditText = findViewById(R.id.username_login_edit_text);
        passwordLoginEditText = findViewById(R.id.password_login_edit_text);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);

        // Configurar listeners para los botones
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarSesion();
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarUsuario();
            }
        });
    }

    private void iniciarSesion() {
        String username = usernameLoginEditText.getText().toString();
        String password = passwordLoginEditText.getText().toString();

        // Implementar la lógica de autenticación aquí
        // Por ahora, simularemos un inicio de sesión correcto si ambos campos no están vacíos
        if (!username.isEmpty() && !password.isEmpty()) {
            // Si el inicio de sesión es exitoso, mostramos un mensaje y guardamos el estado de inicio de sesión
            guardarEstadoInicioSesion(true);
            Toast.makeText(LoginActivity.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Cerrar la actividad actual
        } else {
            // Si el inicio de sesión falla, mostramos un mensaje de error
            Toast.makeText(LoginActivity.this, "Nombre de usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para guardar el estado de inicio de sesión
    private void guardarEstadoInicioSesion(boolean isLoggedIn) {
        SharedPreferences sharedPreferences = getSharedPreferences("login_preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", isLoggedIn);
        editor.apply();
    }

    // Método para registrar un nuevo usuario
    private void registrarUsuario() {
        final String username = usernameLoginEditText.getText().toString();
        final String password = passwordLoginEditText.getText().toString();

        // Ejecutar la operación de inserción de usuario en un AsyncTask
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                // Crear un nuevo usuario y guardarlo en la base de datos
                Usuario newUser = new Usuario();
                newUser.setUsername(username);
                newUser.setPassword(password);
                appDatabase.usuarioDao().insert(newUser);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                // Mostrar un mensaje de éxito
                Toast.makeText(LoginActivity.this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show();
            }
        }.execute();
    }

}
