package com.example.expensemate.ui.api;

import com.google.gson.annotations.SerializedName;

public class Gasto {
    @SerializedName("id")
    private int id;

    @SerializedName("descripcion")
    private String descripcion;

    @SerializedName("cantidad")
    private double cantidad;

    @SerializedName("id_proyecto")
    private int idProyecto;

    // Constructor
    public Gasto(String descripcion, double cantidad, int idProyecto) {
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.idProyecto = idProyecto;
    }

    // Métodos getter y setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public int getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(int idProyecto) {
        this.idProyecto = idProyecto;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Descripción: " + descripcion + ", Cantidad: " + cantidad + ", ID Proyecto: " + idProyecto;
    }
}
