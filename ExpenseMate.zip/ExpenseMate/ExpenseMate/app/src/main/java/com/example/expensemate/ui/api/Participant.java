package com.example.expensemate.ui.api;

public class Participant {
    private int id;
    private int role;
    private int userId;
    private int projectId;

    public Participant(int id, int role, int userId, int projectId) {
        this.id = id;
        this.role = role;
        this.userId = userId;
        this.projectId = projectId;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
}
