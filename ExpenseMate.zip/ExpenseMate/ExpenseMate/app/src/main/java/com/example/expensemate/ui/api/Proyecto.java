package com.example.expensemate.ui.api;

public class Proyecto {
    private int id;
    private String nombre;
    private int id_admin;

    public Proyecto(String nombre, int id_admin) {
        this.nombre = nombre;
        this.id_admin = id_admin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId_admin() {
        return id_admin;
    }

    public void setId_admin(int id_admin) {
        this.id_admin = id_admin;
    }
}
