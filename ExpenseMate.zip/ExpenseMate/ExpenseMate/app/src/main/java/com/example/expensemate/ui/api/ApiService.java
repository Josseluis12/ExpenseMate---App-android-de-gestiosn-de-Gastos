package com.example.expensemate.ui.api;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {

    // Endpoints relacionados con los usuarios
    @POST("registro")
    Call<Void> createUser(@Body User user);

    @GET("usuarios")
    Call<List<User>> getUsers();

    @POST("login")
    Call<TokenResponse> loginUser(@Body User user);

    // Endpoints relacionados con los proyectos
    @POST("proyectos")
    Call<Void> createProject(@Body Proyecto project);

    @GET("proyectos")
    Call<List<Proyecto>> getProyectos();

    @GET("proyectos/{id}")
    Call<Proyecto> getProjectById(@Path("id") int projectId);

    @DELETE("proyectos/{id}")
    Call<Void> deleteProject(@Path("id") int projectId);

    // Endpoints relacionados con los gastos
    @POST("gastos")
    Call<Void> createExpense(@Body Expense expense);

    @GET("gastos")
    Call<List<Gasto>> obtenerGastos();

    @GET("gastos/{id}")
    Call<Expense> getExpenseById(@Path("id") int expenseId);

    @DELETE("gastos/{id}")
    Call<Void> deleteExpense(@Path("id") int expenseId);
}
