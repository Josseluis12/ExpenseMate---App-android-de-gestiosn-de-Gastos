package com.example.expensemate.ui.api;

public class Balance {
    private int id;
    private double amount;
    private int participantId;
    private int expenseId;

    public Balance(int id, double amount, int participantId, int expenseId) {
        this.id = id;
        this.amount = amount;
        this.participantId = participantId;
        this.expenseId = expenseId;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getParticipantId() {
        return participantId;
    }

    public void setParticipantId(int participantId) {
        this.participantId = participantId;
    }

    public int getExpenseId() {
        return expenseId;
    }

    public void setExpenseId(int expenseId) {
        this.expenseId = expenseId;
    }
}
