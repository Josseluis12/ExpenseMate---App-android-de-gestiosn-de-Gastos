package com.example.expensemate.ui.AddProyectos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.ui.api.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private List<User> userList;
    private OnUserClickListener onUserClickListener;

    public UserAdapter(List<User> userList, OnUserClickListener onUserClickListener) {
        this.userList = userList;
        this.onUserClickListener = onUserClickListener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item, parent, false);
        return new UserViewHolder(itemView, onUserClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        CheckBox checkBoxUser;
        TextView textViewUsername;
        OnUserClickListener onUserClickListener;

        public UserViewHolder(@NonNull View itemView, OnUserClickListener onUserClickListener) {
            super(itemView);
            checkBoxUser = itemView.findViewById(R.id.checkbox_user);
            textViewUsername = itemView.findViewById(R.id.textview_username);
            this.onUserClickListener = onUserClickListener;
            checkBoxUser.setOnClickListener(this);
        }

        public void bind(User user) {
            textViewUsername.setText(user.getUsername());
            checkBoxUser.setChecked(user.isSelected());
        }

        @Override
        public void onClick(View v) {
            onUserClickListener.onUserClick(userList.get(getAdapterPosition()), checkBoxUser.isChecked());
        }
    }

    public interface OnUserClickListener {
        void onUserClick(User user, boolean isSelected);
    }
}
