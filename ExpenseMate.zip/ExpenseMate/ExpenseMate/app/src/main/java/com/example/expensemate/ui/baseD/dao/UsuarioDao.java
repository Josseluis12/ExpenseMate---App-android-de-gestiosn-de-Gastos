// UsuarioDao.java
package com.example.expensemate.ui.baseD.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Update;
import androidx.room.Delete;
import androidx.room.Query;
import com.example.expensemate.ui.baseD.Usuario;

@Dao
public interface UsuarioDao {
    @Insert
    void insert(Usuario usuario);

    @Update
    void update(Usuario usuario);

    @Delete
    void delete(Usuario usuario);

    @Query("SELECT * FROM usuarios WHERE username = :username")
    Usuario findByUsername(String username);

    // Más métodos según sea necesario...
}