// Gasto.java
package com.example.expensemate.ui.baseD;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "gastos",
        foreignKeys = {
                @ForeignKey(entity = Proyecto.class,
                        parentColumns = "id",
                        childColumns = "proyecto_id",
                        onDelete = ForeignKey.CASCADE),
                @ForeignKey(entity = Usuario.class,
                        parentColumns = "id",
                        childColumns = "usuario_id",
                        onDelete = ForeignKey.CASCADE)
        })
public class Gasto {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "proyecto_id")
    public int proyectoId;

    @ColumnInfo(name = "monto")
    public double monto;

    @ColumnInfo(name = "descripcion")
    public String descripcion;

    @ColumnInfo(name = "fecha")
    public String fecha;

    @ColumnInfo(name = "usuario_id")
    public int usuarioId;

    // Constructor, getters y setters...

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProyectoId() {
        return proyectoId;
    }

    public void setProyectoId(int proyectoId) {
        this.proyectoId = proyectoId;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
