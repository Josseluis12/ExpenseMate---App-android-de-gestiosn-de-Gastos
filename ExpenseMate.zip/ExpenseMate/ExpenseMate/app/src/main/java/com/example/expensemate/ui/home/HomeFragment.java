package com.example.expensemate.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.expensemate.R;
import com.example.expensemate.ui.api.ApiService;
import com.example.expensemate.ui.api.Proyecto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProyectoAdapter proyectoAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = root.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        proyectoAdapter = new ProyectoAdapter();
        recyclerView.setAdapter(proyectoAdapter);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://josseluis12.eu.pythonanywhere.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        Call<List<Proyecto>> call = apiService.getProyectos();
        call.enqueue(new Callback<List<Proyecto>>() {
            @Override
            public void onResponse(Call<List<Proyecto>> call, Response<List<Proyecto>> response) {
                if (response.isSuccessful()) {
                    List<Proyecto> proyectos = response.body();
                    if (proyectos != null && !proyectos.isEmpty()) {
                        proyectoAdapter.setProyectos(proyectos);
                        Toast.makeText(getContext(), "Proyectos cargados correctamente", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "No se encontraron proyectos", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    try {
                        Log.e("Response Error", response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Toast.makeText(getContext(), "Error al obtener proyectos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Proyecto>> call, Throwable t) {
                Toast.makeText(getContext(), "Error de red: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return root;
    }

    private static class ProyectoAdapter extends RecyclerView.Adapter<ProyectoAdapter.ProyectoViewHolder> {
        private List<Proyecto> proyectos = new ArrayList<>();

        public void setProyectos(List<Proyecto> proyectos) {
            this.proyectos = proyectos;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ProyectoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.project_item, parent, false);
            return new ProyectoViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull ProyectoViewHolder holder, int position) {
            Proyecto proyecto = proyectos.get(position);
            holder.bind(proyecto);
        }

        @Override
        public int getItemCount() {
            return proyectos.size();
        }

        static class ProyectoViewHolder extends RecyclerView.ViewHolder {
            private final TextView textViewNombre;

            public ProyectoViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewNombre = itemView.findViewById(R.id.text_view_name);
            }

            public void bind(Proyecto proyecto) {
                textViewNombre.setText(proyecto.getNombre());
            }
        }
    }
}
