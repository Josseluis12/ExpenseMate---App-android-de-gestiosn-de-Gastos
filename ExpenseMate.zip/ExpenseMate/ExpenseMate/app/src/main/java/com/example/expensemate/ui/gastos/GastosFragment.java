package com.example.expensemate.ui.gastos;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expensemate.R;
import com.example.expensemate.ui.api.ApiClient;
import com.example.expensemate.ui.api.ApiService;
import com.example.expensemate.ui.api.Gasto; // Importa la clase Gasto
import com.example.expensemate.ui.api.Expense;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GastosFragment extends Fragment {

    private List<Gasto> listaGastos; // Cambia a List<Gasto>

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_gastos, container, false);

        final TextView textView = root.findViewById(R.id.text_gallery);

        // Llamar a la API para obtener los gastos
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<Gasto>> call = apiService.obtenerGastos(); // Cambiado a List<Gasto>
        call.enqueue(new Callback<List<Gasto>>() { // Cambiado a List<Gasto>
            @Override
            public void onResponse(Call<List<Gasto>> call, Response<List<Gasto>> response) { // Cambiado a List<Gasto>
                if (response.isSuccessful()) {
                    listaGastos = response.body();
                    // Mostrar los gastos en el TextView o en un RecyclerView
                    if (listaGastos != null && !listaGastos.isEmpty()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        for (Gasto gasto : listaGastos) { // Cambiado a Gasto
                            stringBuilder.append(gasto.toString()).append("\n");
                        }
                        textView.setText(stringBuilder.toString());
                    } else {
                        textView.setText("No se encontraron gastos.");
                    }
                } else {
                    textView.setText("Error al obtener los gastos.");
                }
            }

            @Override
            public void onFailure(Call<List<Gasto>> call, Throwable t) { // Cambiado a List<Gasto>
                textView.setText("Error de red: " + t.getMessage());
            }
        });

        // Botón "Nuevo Gasto" para agregar un nuevo gasto
        Button buttonNuevoGasto = root.findViewById(R.id.button_nuevo_gasto);
        buttonNuevoGasto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mostrar la ventana emergente para agregar un nuevo gasto
                mostrarVentanaAgregarGasto();
            }
        });

        return root;
    }

    // Método para mostrar la ventana emergente de agregar un nuevo gasto
    private void mostrarVentanaAgregarGasto() {
        // Implementa la lógica para mostrar la ventana emergente de agregar un nuevo gasto
    }
}
