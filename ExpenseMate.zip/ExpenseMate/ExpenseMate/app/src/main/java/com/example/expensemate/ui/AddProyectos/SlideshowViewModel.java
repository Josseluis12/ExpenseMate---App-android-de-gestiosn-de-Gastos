// SlideshowViewModel.java

package com.example.expensemate.ui.AddProyectos;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.expensemate.ui.api.ApiClient;
import com.example.expensemate.ui.api.ApiService;
import com.example.expensemate.ui.api.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SlideshowViewModel extends ViewModel {
    private final MutableLiveData<List<User>> listaUsuariosLiveData = new MutableLiveData<>();
    private final MutableLiveData<Boolean> proyectoAgregadoLiveData = new MutableLiveData<>();

    public void obtenerListaUsuarios() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<User>> call = apiService.getUsers();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful()) {
                    listaUsuariosLiveData.setValue(response.body());
                } else {
                    Log.e("SlideshowViewModel", "Error al obtener la lista de usuarios: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Log.e("SlideshowViewModel", "Error al obtener la lista de usuarios: " + t.getMessage());
            }
        });
    }

    public void agregarProyecto(String nombreProyecto, List<User> listaUsuarios, String descripcion, double importe) {
        Log.d("SlideshowViewModel", "Nombre del proyecto: " + nombreProyecto);
        Log.d("SlideshowViewModel", "Descripción: " + descripcion);
        Log.d("SlideshowViewModel", "Importe: " + importe);
        for (User usuario : listaUsuarios) {
            Log.d("SlideshowViewModel", "Usuario: " + usuario.getUsername());
        }

        boolean proyectoAgregado = true;
        proyectoAgregadoLiveData.setValue(proyectoAgregado);
    }

    public LiveData<List<User>> getListaUsuariosLiveData() {
        return listaUsuariosLiveData;
    }

    public LiveData<Boolean> getProyectoAgregadoLiveData() {
        return proyectoAgregadoLiveData;
    }
}
